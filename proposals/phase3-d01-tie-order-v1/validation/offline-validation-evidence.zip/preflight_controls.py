from contextlib import redirect_stderr
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile

root=Path(__file__).resolve().parents[2]
proposal=root/'work/phase3-d01-tie-order-v1/proposals/phase3-d01-tie-order-v1'
spec=importlib.util.spec_from_file_location('_preflight_candidate',proposal/'run_validation.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
config=json.loads((proposal/'synthetic-config.json').read_text());results=[]
with tempfile.TemporaryDirectory() as directory:
 directory=Path(directory)
 variants=[]
 for key,value in [('activation',True),('authorized_treatment_a_attempts',1),('authorized_treatment_a_attempts',False),('state','active'),('source_commit','not-a-commit'),('metric','phase3-d01-provenance-v1')]:
  c=copy.deepcopy(config);c[key]=value;variants.append((key+'-'+str(value),c))
 c=copy.deepcopy(config);c['source_sha256']['tie_sql_proof.py']='0'*64;variants.append(('stale-source',c))
 for i,(name,c) in enumerate(variants):
  file=directory/f'config-{i}.json';file.write_text(json.dumps(c));output=directory/f'out-{i}.json'
  sys.argv=['run_validation.py','--configuration',str(file),'--output',str(output)]
  before=runner.upstream.observations['memory_sqlite_connections'];stderr=io.StringIO();code=None
  try:
   with redirect_stderr(stderr):runner.main()
  except SystemExit as e:code=e.code
  assert code==2 and not output.exists() and runner.upstream.observations['memory_sqlite_connections']==before
  results.append({'id':name,'exit_code':code,'memory_sqlite_connections_created':0,'output_created':False,'stderr':stderr.getvalue()})
 output=directory/'existing.json';output.write_text('original evidence\n');sys.argv=['run_validation.py','--output',str(output)]
 try:
  with redirect_stderr(io.StringIO()):runner.main()
 except SystemExit as e:code=e.code
 assert code==2 and output.read_text()=='original evidence\n' and runner.upstream.observations['memory_sqlite_connections']==0
 results.append({'id':'overwrite-refused','exit_code':code,'original_evidence_unchanged':True,'memory_sqlite_connections_created':0})
report={'cases':results,'passed':True,'side_effect_guard':runner.upstream.observations}
Path(sys.argv_saved_output).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n') if hasattr(sys,'argv_saved_output') else print(json.dumps(report,indent=2,sort_keys=True))
