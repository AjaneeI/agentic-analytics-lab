"""Full-suite guard inherited by explicitly inspected Python test subprocesses."""
import os
from pathlib import Path
import sys

def guard(event,args):
    denied=event.startswith('socket.') or event in ('os.system','os.fork','os.forkpty')
    if event=='sqlite3.connect' and args[0]!=':memory:':denied=True
    if event=='subprocess.Popen':
        denied=Path(args[0]).resolve()!=Path(sys.executable).resolve()
    if denied:raise RuntimeError('offline full-suite guard forbids '+event)
sys.addaudithook(guard)
