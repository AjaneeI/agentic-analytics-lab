"""Full-suite guard inherited by explicitly inspected Python test subprocesses."""
import os
from pathlib import Path
import sys

def guard(event,args):
    denied=event.startswith('socket.') or event in ('os.system','os.fork','os.forkpty')
    if event=='sqlite3.connect' and args[0]!=':memory:':denied=True
    if event=='subprocess.Popen':
        python_child=Path(args[0]).resolve()==Path(sys.executable).resolve()
        git_metadata=args[0]=='git' and args[1]==['git','rev-parse','--is-inside-work-tree']
        denied=not (python_child or git_metadata)
    if denied:raise RuntimeError('offline full-suite guard forbids '+event)
sys.addaudithook(guard)
