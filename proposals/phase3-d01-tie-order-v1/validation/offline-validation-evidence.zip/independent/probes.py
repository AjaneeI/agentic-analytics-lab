"""Independent NEW synthetic controls. Guards install before candidate imports.

No historical analytical SQL, frozen dataset, runtime or live execution is used.
Run only against the reviewed immutable checkout and write fresh report paths.
"""
import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import platform
import sys
from fractions import Fraction
from functools import cmp_to_key

ROOT=Path('/Users/ajaneeigharo/Documents/Codex/2026-10-17/execute-the-phase-2-5-acceleration/work/phase3-d01-tie-order-v1')
HERE=ROOT/'proposals/phase3-d01-tie-order-v1'
GUARD=ROOT/'proposals/phase3-d01-provenance-v1/run_validation.py'
spec=importlib.util.spec_from_file_location('_independent_upstream_guard',GUARD)
guard=importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
# The unchanged upstream module installed its audit/import guards above, before
# importing either the candidate or any new fixture helpers.
sys.path.insert(0,str(HERE))
import test_tie_order as t


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if args.output.exists():parser.error('refusing to overwrite evidence')
    t.CONFIG=json.loads((HERE/'synthetic-config.json').read_text())
    cases=[]

    def record(name,expected,verdict,**details):
        cases.append(dict(id=name,expected=expected,observed=verdict['status'],
            reason=verdict['reason'],live_qualified=verdict['live_qualified'],**details))

    # Independent selection oracle: compare the multiset of selected key tuples
    # against the first K key tuples of the complete exact mathematical ranking.
    # This does not reconstruct candidate required/admissible row sets.
    def compare(a,b,fields):
        for field,direction in fields:
            if a[field]!=b[field]:return (1 if a[field]>b[field] else -1)*direction
        return 0

    populations=[
        (('Aster',1,1),('Birch',2,2),('Cedar',2,2),('Dahlia',3,3),('Elm',1,2),('Fir',0,1)),
        (('Aster',1,3),('Birch',2,6),('Cedar',1,3),('Dahlia',1,4),('Elm',0,2)),
        (('Aster',0,1),('Birch',0,2),('Cedar',0,2),('Dahlia',0,3)),
    ]
    orders=[(('rate',-1),), (('rate',-1),('size',1)),
        (('rate',-1),('size',-1)),(('rate',-1),('size',1),('team',-1)),
        (('rate',-1),('size',-1),('num',1)),
        (('rate',-1),('size',1),('num',-1),('team',1))]
    for p,specification in enumerate(populations):
        snapshot=t.snapshot(specification)
        exact=[dict(team=team,rate=100*Fraction(b,n),size=n,num=b) for team,b,n in specification]
        maximum=max(row['rate'] for row in exact)
        winners=[row['team'] for row in exact if row['rate']==maximum]
        for o,fields in enumerate(orders):
            ranked=sorted(exact,key=cmp_to_key(lambda a,b:compare(a,b,fields)))
            for limit in range(1,len(exact)+2):
                sql=("SELECT team,100.0*SUM(blocked)/COUNT(*) AS rate,COUNT(*) AS size,SUM(blocked) AS num "
                    "FROM delivery_work_items WHERE status!='done' GROUP BY team ORDER BY "+
                    ', '.join(field+(' ASC' if direction==1 else ' DESC') for field,direction in fields)+
                    ' LIMIT '+str(limit))
                prefix=ranked[:limit]
                prefix_keys=sorted(tuple(row[field] for field,_ in fields) for row in prefix)
                for c,subset in enumerate(itertools.combinations(exact,min(limit,len(exact)))):
                    subset_keys=sorted(tuple(row[field] for field,_ in fields) for row in subset)
                    members={row['team'] for row in subset}
                    selected_winners=members.intersection(winners)
                    legitimate=subset_keys==prefix_keys
                    team=sorted(selected_winners)[0] if selected_winners else subset[0]['team']
                    winner=next(row for row in exact if row['team']==team)
                    captured=[dict(row,rate=float(row['rate'])) for row in reversed(subset)]
                    host=t.Host(sql,snapshot,captured)
                    verdict=t.check(host,team,float(winner['rate']),len(winners)==1)
                    record(f'exhaustive-p{p}-o{o}-k{limit}-c{c}',
                        'proven' if legitimate and selected_winners else 'contradicted',verdict,
                        captured_teams=sorted(members),key_multiset_matches=legitimate)

    # High precision secondary keys differ by much less than reconciliation
    # tolerance. A rounded float key is never allowed to turn a loser into peer.
    fine_snapshot=t.snapshot((('Aster',1,1),('Birch',2,2),('Cedar',3,3)))
    sql=("SELECT team,100.0*SUM(blocked)/COUNT(*) AS rate,"
        "1+COUNT(*)/100000000000000.0 AS fine "
        "FROM delivery_work_items WHERE status!='done' GROUP BY team ORDER BY rate DESC, fine ASC LIMIT 1")
    for team,expected in [('Aster','proven'),('Birch','contradicted'),('Cedar','contradicted')]:
        # The actual float fine values are supplied, not exact Fraction objects.
        fine={'Aster':1.00000000000001,'Birch':1.00000000000002,'Cedar':1.00000000000003}[team]
        h=t.Host(sql,fine_snapshot,[dict(team=team,rate=100.0,fine=fine)])
        record('exact-secondary-'+team,expected,t.check(h,team))

    # New synthetics for cardinality, projection and captured-member invariants.
    snapshot=t.snapshot((('Aster',1,1),('Birch',1,1),('Cedar',1,1)))
    base_sql=t.SQL.replace('LIMIT 1','LIMIT 2')
    for name,captured in [
        ('too-few',[dict(team='Aster',rate=100.0)]),
        ('too-many',[dict(team=x,rate=100.0) for x in ('Aster','Birch','Cedar')]),
        ('duplicate',[dict(team='Aster',rate=100.0)]*2),
        ('missing-metric',[dict(team='Aster'),dict(team='Birch',rate=100.0)]),
        ('extra-key',[dict(team='Aster',rate=100.0,x=0),dict(team='Birch',rate=100.0)]),
        ('forged-rate',[dict(team='Aster',rate=99.9),dict(team='Birch',rate=100.0)]),
        ('bool-rate',[dict(team='Aster',rate=True),dict(team='Birch',rate=100.0)]),
        ('string-rate',[dict(team='Aster',rate='100'),dict(team='Birch',rate=100.0)]),
        ('case-collision',[dict(team='Aster',rate=100.0,RATE=100.0),dict(team='Birch',rate=100.0)]),
    ]:
        h=t.Host(base_sql,snapshot,captured)
        record('adversarial-'+name,'contradicted',t.check(h,'Aster'))
    h=t.Host(base_sql,snapshot,[dict(team='Aster',rate=100.0),dict(team='Birch',rate=100.0)])
    record('uncaptured-exact-winner','contradicted',t.check(h,'Cedar'))
    record('false-unique-among-truncated-co-max','contradicted',t.check(h,'Aster',unique=True))
    record('claim-tolerance-upper-bound','proven',t.check(h,'Aster',rate=100.2))
    record('claim-tolerance-outside','contradicted',t.check(h,'Aster',rate=100.200001))

    # Guard self-checks invoke guard policy directly, never a prohibited effect.
    before=len(guard.observations['blocked_side_effect_attempts'])
    denied=[]
    for event,event_args in [('socket.__new__',()),('subprocess.Popen',()),
        ('os.system',()),('os.posix_spawn',()),('os.fork',()),('sqlite3.connect',('/tmp/forbidden.db',))]:
        try:guard.guard(event,event_args)
        except RuntimeError:denied.append(event)
        else:raise AssertionError('guard did not deny '+event)
    runtime_denied=False
    try:guard.NoRuntime().find_spec('src.forbidden_runtime_probe')
    except ImportError:runtime_denied=True
    mismatches=[case['id'] for case in cases if case['expected']!=case['observed'] or case['live_qualified'] is not False]
    report=dict(python=platform.python_version(),commit='069407889c46e0a554f25950e77c667589f3138a',
        scope='NEW synthetic data only; memory SQLite captures',case_count=len(cases),cases=cases,
        mismatches=mismatches,side_effect_guard=guard.observations,
        actual_test_guard_denials_before_policy_self_checks=before,
        direct_policy_self_checks=denied,runtime_import_policy_denied=runtime_denied,
        candidate_active=False,live_qualified=False,phase3_accepted=False,new_treatment_a_attempts=0,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        passed=not mismatches and before==0 and len(denied)==6 and runtime_denied)
    with args.output.open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({key:report[key] for key in ('python','case_count','mismatches','passed')}))
    raise SystemExit(0 if report['passed'] else 1)

if __name__=='__main__':main()
